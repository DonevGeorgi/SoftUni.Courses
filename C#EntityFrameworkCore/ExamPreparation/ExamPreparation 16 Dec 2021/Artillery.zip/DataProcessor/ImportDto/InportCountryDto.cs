﻿namespace Artillery.DataProcessor.ImportDto
{
    public class InportCountryDto
    {
        public int Id { get; set; }
    }
}
